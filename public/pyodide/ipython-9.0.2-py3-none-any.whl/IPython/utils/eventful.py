from warnings import warn

warn("IPython.utils.eventful has moved to traitlets.eventful", stacklevel=2)

from traitlets.eventful import *
