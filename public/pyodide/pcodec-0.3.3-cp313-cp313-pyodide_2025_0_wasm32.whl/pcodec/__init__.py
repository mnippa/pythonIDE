from .pcodec import *

__doc__ = pcodec.__doc__
if hasattr(pcodec, "__all__"):
    __all__ = pcodec.__all__