"""Decision rules-based algorithms."""

from __future__ import annotations

from .amrules import AMRules

__all__ = ["AMRules"]
