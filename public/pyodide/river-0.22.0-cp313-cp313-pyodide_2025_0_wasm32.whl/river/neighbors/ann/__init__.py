from __future__ import annotations

from .swinn import SWINN

__all__ = ["SWINN"]
