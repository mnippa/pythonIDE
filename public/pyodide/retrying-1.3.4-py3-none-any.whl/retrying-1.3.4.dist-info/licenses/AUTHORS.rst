Retrying is maintained by Greg Roodt and
various contributors:

Lead Maintainer
````````````````

- Greg Roodt


Original Author
````````````````

- Ray Holder


Contributors
```````````````````````

- Anthony McClosky
- Jason Dunkelberger
- Justin Turner Arthur
- J Derek Wilson
- Alex Kuang
- Simon Dollé
- Rees Dooley
- Saul Shanabrook
- Daniel Nephin
- Simeon Visser
- Joshua Harlow
- Pierre-Yves Chibon
- Haïkel Guémar
- Thomas Goirand
- James Page
- Josh Marshall
- Dougal Matthews
- Monty Taylor
- Maxym Shalenyi
- Jonathan Herriott
- Job Evers
- Cyrus Durgin
