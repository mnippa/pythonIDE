from .write_instance import write_instance as write_instance
from .write_solution import write_solution as write_solution
