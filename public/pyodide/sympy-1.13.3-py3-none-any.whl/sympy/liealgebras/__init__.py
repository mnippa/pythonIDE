from sympy.liealgebras.cartan_type import CartanType

__all__ = ['CartanType']
