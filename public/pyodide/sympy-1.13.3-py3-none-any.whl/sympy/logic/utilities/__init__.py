from .dimacs import load_file

__all__ = ['load_file']
