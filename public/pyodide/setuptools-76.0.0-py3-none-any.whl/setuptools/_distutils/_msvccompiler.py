from .compilers.C import msvc

MSVCCompiler = msvc.Compiler
