Geometry
--------

Optimised geometric functions

.. automodule:: bilby_cython.geometry
   :members:
