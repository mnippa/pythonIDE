"""The pytest entry point."""

from __future__ import annotations

import pytest


if __name__ == "__main__":
    raise SystemExit(pytest.console_main())
